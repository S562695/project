//
//  ViewController.swift
//  S566460CarsApp
//
//  Created by vikas allam on 4/4/24.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        // 1. What is the purpose of protocols in Swift?
        let purposeOfProtocols = "Protocols in Swift define a set of methods, properties, and other requirements that a class, structure, or enumeration can implement. They are used to define a blueprint of methods and properties that can be adopted by any class, regardless of its inheritance."
        print("1. Purpose of protocols in Swift:")
        print(purposeOfProtocols)
        
        // 2. What data structure is used by a Tab Bar Controller to manage its view controllers?
        let tabBarControllerDataStructure = "A Tab Bar Controller uses an array data structure to manage its view controllers. This array contains references to the view controllers that are displayed as tabs on the tab bar interface."
        print("\n2. Data structure used by a Tab Bar Controller:")
        print(tabBarControllerDataStructure)
        
        // 3. What is a tab bar item in a view controller?
        let tabBarViewItem = "A tab bar item in a view controller is an object that represents a single tab on a tab bar interface. It typically contains properties such as an image, a title, and other attributes that define the appearance and behavior of the tab."
        print("\n3. Tab bar item in a view controller:")
        print(tabBarViewItem)
    }
    
        
        
        
        
        
        
        
        
        
        
        
        
        
    }


}

