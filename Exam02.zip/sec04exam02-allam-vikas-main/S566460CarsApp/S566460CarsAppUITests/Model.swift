import Foundation

struct Car {
    var make: String
    var model: String
    var price: Double
    
    init(make: String, model: String, price: Double) {
        self.make = make
        self.model = model
        self.price = price
    }
}

struct DataManager {
    static let sharedDataManager = DataManager()
    
    private let cars = [
        "economy":
            [
                Car(make: "Toyota", model: "Corolla", price: 25_725),
                Car(make: "Honda", model: "Civic", price: 29_400),
                Car(make: "Hyundai", model: "Elantra", price: 25_450),
                Car(make: "Ford", model: "Focus", price: 24_000),
                Car(make: "Nissan", model: "Sentra", price: 24_800)
            ],
        "luxury":
            [
                Car(make: "Mercedes-Benz", model: "S-Class", price: 191_600),
                Car(make: "BMW", model: "7 Series", price: 159_000),
                Car(make: "Audi", model: "A8", price: 101_000),
                Car(make: "Lexus", model: "LS", price: 83_000),
                Car(make: "Jaguar", model: "XJ", price: 85_500)
            ]
    ]
    
    func fetchCars() -> [String: [Car]] {
        self.cars
    }
}
