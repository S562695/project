//
//  ViewController.swift
//  S566460SlotMachineApp
//
//  Created by Vikas on 3/31/24.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

