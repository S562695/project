//
//  SlotMachineVC.swift
//  S566460SlotMachineApp
//
//  Created by Vikas on 3/31/24.
//

import UIKit
import AVFoundation

class SlotMachineVC: UIViewController {
    
    var totalNoofCredits = 1000
    
    var currentBetAmount = 100
    
    let symbols = ["🍒", "🍋", "🍒", "💎", "🍋", "🍒", "💎", "🍒", "🍋", "🍒", "🍋", "💎", "🍒", "🍋", "🍒", "💎", "🍒", "🍋", "🍒", "💎", "🍋", "🍒", "💎", "🍋", "🍒",  "💎", "🍒", "🍋"]
    
    var spinning = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        slotsPV.dataSource = self
        slotsPV.delegate = self
        creditsLBL.text = "Credits: \(totalNoofCredits)"
        betLBL.text = "Bet: \(currentBetAmount)"
        // Do any additional setup after loading the view.
    }
    
    @IBOutlet weak var headerLBL: UILabel!
    
    @IBOutlet weak var creditsLBL: UILabel!
    
    @IBOutlet weak var betLBL: UILabel!
    
    @IBOutlet weak var slotsPV: UIPickerView!
    
    @IBOutlet weak var betStepper: UIStepper!
    
    @IBOutlet weak var spinBTN: UIButton!
    
    
    @IBAction func updateBetAmount(_ sender: UIStepper) {
        currentBetAmount = Int(sender.value) * 100
        betLBL.text = "Bet: \(currentBetAmount)"
    }
    
    
    @IBAction func spinSlotMachine(_ sender: UIButton) {
        guard !spinning && currentBetAmount <= totalNoofCredits else { return }
        spinning = true
        spinBTN.isEnabled = false
        totalNoofCredits -= currentBetAmount
        creditsLBL.text = "Credits: \(totalNoofCredits)"
        var selectedRow1 = Int.random(in: 0..<symbols.count)
        var selectedRow2 = Int.random(in: 0..<symbols.count)
        var selectedRow3 = Int.random(in: 0..<symbols.count)
        slotsPV.selectRow(selectedRow1, inComponent: 0, animated: true)
        slotsPV.selectRow(selectedRow2, inComponent: 1, animated: true)
        slotsPV.selectRow(selectedRow3, inComponent: 2, animated: true)
        
        play()
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
            let selectedSymbol1 = self.symbols[selectedRow1]
            let selectedSymbol2 = self.symbols[selectedRow2]
            let selectedSymbol3 = self.symbols[selectedRow3]
            self.finalOutputCheck([selectedSymbol1, selectedSymbol2, selectedSymbol3])
            self.spinning = false
            self.spinBTN.isEnabled = true
        }
    }
    
    func play() {
    AudioServicesPlaySystemSound(1104)
    }
    
    func finalOutputCheck(_ symbols: [String]) {
    if symbols[0] == symbols[1] && symbols[1] == symbols[2] {
        var mul = 1
        switch symbols[0] {
        case "🍒":
        mul = 2
        case "🍋":
        mul = 3
        case "💎":
        mul = 5
        default:
        break
            }
        let totalWin = currentBetAmount * mul
        totalNoofCredits += totalWin
        creditsLBL.text = "Credits: \(totalNoofCredits)"
        showAlert(message: "You won \(totalWin) credits!")
        } else {
                showAlert(message: "Try again!")
            }
    }
    
    func showAlert(message: String) {
        let msg = UIAlertController(title: "Result", message: message, preferredStyle: .alert)
        msg.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        self.present(msg, animated: true, completion: nil)
    }
    
}

extension SlotMachineVC: UIPickerViewDataSource, UIPickerViewDelegate {
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
    return 3
    }
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
    return symbols.count
}
    func pickerView(_ pickerView: UIPickerView, rowHeightForComponent component: Int) -> CGFloat {
      return 100
}
    
    func pickerView(_ pickerView: UIPickerView, viewForRow row: Int, forComponent component: Int, reusing view: UIView?) -> UIView {
    let label = UILabel()
   label.text = symbols[row]
   label.font = UIFont.systemFont(ofSize: 20)
   label.textAlignment = .center
   return label
}
    func pickerView(_ pickerView: UIPickerView, attributedTitleForRow row: Int, forComponent component: Int) -> NSAttributedString? {
        let symbolsize = symbols[row]
        let attributedString = NSAttributedString(string: symbolsize, attributes: [NSAttributedString.Key.foregroundColor: UIColor.black, NSAttributedString.Key.font: UIFont.systemFont(ofSize: 0.1)])
        return attributedString
    }
    
}
