//
//  JackpotVC.swift
//  S566460JackpotApp
//
//  Created by Vikas on 3/1/24.
//

import UIKit

class JackpotVC: UIViewController {

    var bal: Int = 1000
        let sym = ["cat.fill", "dog.fill", "hare.fill"]
        var isWin = true
        var selectedSegmentedIndex=0
        //segmentIndex=1
        @IBOutlet weak var img2: UIImageView!
        @IBOutlet weak var img1: UIImageView!
        @IBOutlet weak var img3: UIImageView!
        
        override func viewDidLoad() {
            super.viewDidLoad()
            // Do any additional setup after loading the view.
            // Set up initial conditions
                    rulesLBL.text = """
                        Royal blind is 100 coins - 2x rewards
                        Elite blind is 200 coins - 4x rewards
                   
 """
     
                    UpdateBalanceLabel()
     
                    gameRoundSC.removeAllSegments()
                    gameRoundSC.insertSegment(withTitle: "Royal", at: 0, animated: false)
                    gameRoundSC.insertSegment(withTitle: "Elite", at: 1, animated: false)
                    
                    // Set the default selection for the gameRoundSC to Royal
                    gameRoundSC.selectedSegmentIndex = 0
     
                    // Display the asset jackpot for each image view
                    img1.image = UIImage(named: "jackpot")
                    img2.image = UIImage(named: "jackpot")
                    img3.image = UIImage(named: "jackpot")
     
                    // Enable both Play and Reset buttons
                    playBTN.isEnabled = true
                    resetBTN.isEnabled = true
            
            
        }
        
        @IBOutlet weak var rulesLBL: UILabel!
        
        @IBOutlet weak var balanceLBL: UILabel!
        
        @IBOutlet weak var gameRoundSC: UISegmentedControl!
        
        
        @IBAction func gamemethod(_ sender: UISegmentedControl) {
            selectedSegmentedIndex=sender.selectedSegmentIndex
            if selectedSegmentedIndex == 0 {
                img1.image = UIImage(named: "jackpot")
                img2.image = UIImage(named: "jackpot")
                img3.image = UIImage(named: "jackpot")
                
                playBTN.isEnabled=true
                        // Royal blind
                        
                    } else {
                   //elite
                        img1.image = UIImage(named: "jackpot")
                        img2.image = UIImage(named: "jackpot")
                        img3.image = UIImage(named: "jackpot")
                        playBTN.isEnabled=true
                                    
                                }
     
                    UpdateBalanceLabel()
          
                    if bal <= 0 {
                        showResetAlert()
                    }
        }
        
        
        @IBOutlet weak var symbolCLCTN: UIStackView!
        
        @IBOutlet weak var playBTN: UIButton!
        
        @IBAction func play(_ sender: UIButton) {
            playBTN.isEnabled=false
            img1.image = UIImage(systemName: sym.randomElement()!)
            img2.image = UIImage(systemName: sym.randomElement()!)
            img3.image = UIImage(systemName: sym.randomElement()!)
     
        let image1 = img1.image
        let image2 = img2.image
        let image3 = img3.image
     
        if let img1 = image1, let img2 = image2, let img3 = image3 {
            if img1.isEqual(img2) && img2.isEqual(img3) {
                // Images in all three image views are equal
                isWin=true
            } else {
                // Images in at least one pair of image views are not equal
                isWin=false
            }
        }
            if selectedSegmentedIndex == 0 {
                
                
                if isWin {
                    bal += 200
                }
                else{
                    bal -= 100 // Deduct 100 coins
                }
            }
            else{
                if isWin {
                    bal += 800
            }
                else{
                    bal -= 200 // Deduct 100 coins
                }
            }
            UpdateBalanceLabel()
     
            if bal <= 0 {
                showResetAlert()
            }
        }
        @IBOutlet weak var resetBTN: UIButton!
        @IBAction func reset(_ sender: UIButton) {
            resetGame()
        }
       private func UpdateBalanceLabel() {
               balanceLBL.text = "\(bal) coins in hand"
           }
        private func showResetAlert(){
            
            let alert = UIAlertController(title: "Game Over!", message: "You do not have sufficient balance to play more", preferredStyle: .alert)
     
                    alert.addAction(UIAlertAction(title: "Reset", style: .default, handler: { [weak self] _ in
                 
                        self?.resetGame()
                    }))
     
                    present(alert, animated: true, completion: nil)
               }
        func resetGame() {
              
            rulesLBL.text = """
                       Royal blind is 100 coins - 2x rewards
                      Elite blind is 200 coins - 4x rewards
               
 """
            bal=1000
            gameRoundSC.selectedSegmentIndex = 0
                UpdateBalanceLabel()
            playBTN.isEnabled = true
            resetBTN.isEnabled = true
            img1.image = UIImage(named: "jackpot")
            img2.image = UIImage(named: "jackpot")
            img3.image = UIImage(named: "jackpot")
         
            }
        func showAlert(message: String) {
               let alert = UIAlertController(title: "Game Result", message: message, preferredStyle: .alert)
               alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
               present(alert, animated: true, completion: nil)
           }
        
       @IBOutlet weak var ImageSV: UIStackView!
    }
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */


