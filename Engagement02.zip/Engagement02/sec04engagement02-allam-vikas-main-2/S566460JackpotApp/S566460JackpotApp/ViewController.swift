//
//  ViewController.swift
//  S566460JackpotApp
//
//  Created by vikas allam on 3/1/24.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

